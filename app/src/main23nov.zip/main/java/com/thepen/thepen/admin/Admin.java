package com.thepen.thepen.admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.thepen.thepen.MainActivity;
import com.thepen.thepen.R;
import com.thepen.thepen.ThePen;
import com.thepen.thepen.adapters.VideoListAdapter;
import com.thepen.thepen.apiservice.ApiUtil;
import com.thepen.thepen.entity.Registration;
import com.thepen.thepen.entity.User;
import com.thepen.thepen.entity.UserList;
import com.thepen.thepen.entity.Video;
import com.thepen.thepen.entity.VideoList;
import com.thepen.thepen.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class Admin extends AppCompatActivity {
    private TabLayout tabLayout;
    private ListView adminsList;
    private View tblHeader;
    private RecyclerView adminVideoList;
    private RecyclerView.LayoutManager savedListayoutManager;
    private GridLayoutManager mGridLayoutManager ;
    private ArrayList<Video> videos;
    private ArrayList<User> users;
    private TextView exptSubject;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        tabLayout       = findViewById(R.id.tablayout);
        adminsList      = findViewById(R.id.adminsList);
        tblHeader       = findViewById(R.id.tblHeader);
        adminVideoList  = findViewById(R.id.adminVideoList);
        exptSubject  = findViewById(R.id.exptSubject);
        mGridLayoutManager = new GridLayoutManager(Admin.this, 3, GridLayoutManager.VERTICAL, false);
        adminVideoList.setLayoutManager(mGridLayoutManager);
        ApiUtil.getuploadvideoList(new GetAdmnVideoList());
        users=new ArrayList<>();
        setTabLayout();
        listviewListener();
    }

    private void listviewListener() {
        adminsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(tabLayout.getSelectedTabPosition()==4 || tabLayout.getSelectedTabPosition()==6){
                    ChangeRoleDialog mChangeRoleDialog=new ChangeRoleDialog(Admin.this,users.get(i));
                    mChangeRoleDialog.show();
                }
            }
        });
    }

    private void setTabLayout() {
        tabLayout.addTab(tabLayout.newTab().setText("Unpublished"));
        tabLayout.addTab(tabLayout.newTab().setText("published"));
        tabLayout.addTab(tabLayout.newTab().setText("Paid"));
        tabLayout.addTab(tabLayout.newTab().setText("Free"));
        tabLayout.addTab(tabLayout.newTab().setText("Teachers"));
        tabLayout.addTab(tabLayout.newTab().setText("Students"));
        tabLayout.addTab(tabLayout.newTab().setText("Admin 2"));
        tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Log.e("TAB",""+tab.getPosition());
                switch (tab.getPosition()){
                    case 0: visibleVideoList();
                        AdminVideoListAdp adminVideoListAdp2 = new AdminVideoListAdp(Admin.this,videos);
                        adminVideoList.setAdapter(adminVideoListAdp2);
                    case 1:visibleVideoList();
                        AdminVideoListAdp adminVideoListAdp3 = new AdminVideoListAdp(Admin.this,videos);
                        adminVideoList.setAdapter(adminVideoListAdp3);
                        break;
                    case 2:
                        visibleVideoList();
                        ArrayList<Video> paidVideos = new ArrayList<>();
                        if(videos!=null){
                            for(Video video : videos){
                                if(video.charge){
                                    paidVideos.add(video);
                                }
                            }
                            AdminVideoListAdp adminVideoListAdp = new AdminVideoListAdp(Admin.this,paidVideos);
                            adminVideoList.setAdapter(adminVideoListAdp);
                        }
                        break;
                    case 3:
                        visibleVideoList();
                        ArrayList<Video> freeVideos = new ArrayList<>();
                        if(videos!=null){
                            for(Video video : videos){
                                if(!video.charge){
                                    freeVideos.add(video);
                                }
                            }
                            AdminVideoListAdp adminVideoListAdp = new AdminVideoListAdp(Admin.this,freeVideos);
                            adminVideoList.setAdapter(adminVideoListAdp);
                        }break;
                    case 4:tblHeader.setVisibility(View.VISIBLE);
                        adminsList.setVisibility(View.VISIBLE);
                        adminVideoList.setVisibility(View.GONE);
                        exptSubject.setText("Sub Expert");
                        ApiUtil.getUserList("2",new GetUserList());break;
                    case 5:tblHeader.setVisibility(View.VISIBLE);
                        adminsList.setVisibility(View.VISIBLE);
                        adminVideoList.setVisibility(View.GONE);
                        exptSubject.setText("Standard");
                        ApiUtil.getUserList("3",new GetUserList());break;
                    case 6:tblHeader.setVisibility(View.VISIBLE);
                        adminsList.setVisibility(View.VISIBLE);
                        adminVideoList.setVisibility(View.GONE);
                        exptSubject.setText("Sub Expert");
                        ApiUtil.getUserList("1",new GetUserList());break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void visibleVideoList() {
        tblHeader.setVisibility(View.GONE);
        adminVideoList.setVisibility(View.VISIBLE);
    }

    class GetUserList extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            try{
                UserList ul = (UserList) msg.obj;
                Log.e("Size","GetUserList "+ul.usercontents.size());
                users.clear();
                users=ul.usercontents;
                UserListAdapter userListAdapter = new UserListAdapter(Admin.this, ul.usercontents);
                adminsList.setAdapter(userListAdapter);
            }catch(Exception cce){
                Log.d("A",""+cce);
            }
        }
    }
    class GetAdmnVideoList extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            try {
                VideoList  mVideoList =(VideoList) msg.obj;
                videos = mVideoList.getUploadVideoList();
            }catch (Exception e){
                Log.e("VideoList","AAA " +e);
            }
        }
    }
}