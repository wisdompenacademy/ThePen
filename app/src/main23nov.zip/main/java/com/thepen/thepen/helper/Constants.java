package com.thepen.thepen.helper;

import com.thepen.thepen.ThePen;

public class Constants {
//    public static final String DOMAIN_URL = "http://192.168.43.216:8080";//local/
    public static final String DOMAIN_URL = "http://93.188.166.106:8080";//Live
    public static final String FILE_URL = "http://93.188.166.106/";//File
    public static final String HEADER_CONTENT_TYPE = "Content-Type:application/json";
    public static final String HEADER_CONTENT_TYPELogin = "Content-Type:application/x-www-form-urlencoded";
    public static final String HEADER_Authorization = "Authorization:Basic cGFyYW0tY2xpZW50OmhlbmRpLXNlY3JldA==";
    public static final String HEADER_AuthorizationVideo = "Authorization:Bearer ";
}
