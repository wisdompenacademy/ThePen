package com.thepen.thepen.entity;

public class TeacherRegistration {

}
