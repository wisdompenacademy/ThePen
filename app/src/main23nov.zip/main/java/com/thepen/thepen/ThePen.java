package com.thepen.thepen;

import android.app.Application;

public class ThePen extends Application {
     public  static String Standard="10";
     public  static String medium="Marathi";
     public  static String board="Maharashtra";
     public static String subject="Math";
}
